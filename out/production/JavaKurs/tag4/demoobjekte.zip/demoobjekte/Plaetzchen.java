package tag4.demoobjekte;

public class Plaetzchen {

   private int dicke;
  
   private String verzierung;

   public Plaetzchen(int dicke) {
       this.dicke = dicke;
       verzierung = "nichts";
   }

   public String toString() {
       return dicke + " mm mit " + verzierung;
   }
  
}
